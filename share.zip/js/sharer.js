var title= document.title;
var link = document.location.href;
var gp = document.querySelector('.shr.gp');var gph=document.createElement('a');gph.href="https://plus.google.com/share?url="+link;gp.appendChild(gph);
var fb = document.querySelector('.shr.fb');var fbh=document.createElement('a');fbh.href="https://www.facebook.com/sharer.php?u="+link;fb.appendChild(fbh);
var twt = document.querySelector('.shr.twt');var twth=document.createElement('a');twth.href="https://twitter.com/intent/tweet?url="+link+"&text="+title;twt.appendChild(twth);
var pin = document.querySelector('.shr.pin');var pinh=document.createElement('a');pinh.href="https://www.pinterest.com/pin/create/button/?url="+link;pin.appendChild(pinh);
var whats = document.querySelector('.shr.wha');var whtf=document.createElement('a');whtf.href="whatsapp://send?text="+link;whats.appendChild(whtf);

function repos(){
    var shrelm = document.querySelector('.share');
    console.log(window.screen.width);
    console.log(window.screen.availWidth);
    console.log(document.body.clientWidth);
    setInterval(function(){if(window.screen.width > 468){shrelm.style= ''; shrelm.style.top='calc(50% - ' + shrelm.offsetHeight/2 + 'px)'}else{ shrelm.style='';shrelm.style.left='calc(50% - ' + shrelm.offsetWidth/2 + 'px)';}},10);
    
}
//? height offset to center the element
window.onload = repos();
window.addEventListener("resize", function(){
    repos();
});